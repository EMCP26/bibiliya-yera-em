# bibiliya-yera-em
Bible in English, French and Kinyarwanda
